package com.capgemini.HotelManagement.Service;

public interface AdminService {
	public boolean adminService();
}
