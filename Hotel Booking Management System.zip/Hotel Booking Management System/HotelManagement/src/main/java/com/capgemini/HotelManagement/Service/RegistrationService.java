package com.capgemini.HotelManagement.Service;

public interface RegistrationService {

	public boolean registerService();
}
