package com.capgemini.HotelManagement;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.apache.log4j.Logger;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import com.capgemini.HotelManagement.Bean.Room;
import com.capgemini.HotelManagement.DAO.RoomDaoImpl;
import com.capgemini.HotelManagement.Factory.Factory;

public class RoomOperationsTest {
	static Logger log = Logger.getLogger(RoomOperationsTest.class);

	@Test
	@DisplayName("Add Room")
	void testAddRoom() {
		RoomDaoImpl roomoperations = Factory.getRoomDaoImplInstance();
		assertEquals(false, roomoperations.addRoom());
	}

	@Test
	@DisplayName("Delete Room")
	void testDeleteRoom() {
		RoomDaoImpl roomoperations = Factory.getRoomDaoImplInstance();
		assertEquals(false, roomoperations.deleteRoom("112"));
	}

	@Test
	@DisplayName("update Room")
	void testUpdateRoom() {

		RoomDaoImpl roomoperations = Factory.getRoomDaoImplInstance();
		Room room = Factory.getRoomInstance();
		assertEquals(false, roomoperations.updateRoom(room));
	}
}
