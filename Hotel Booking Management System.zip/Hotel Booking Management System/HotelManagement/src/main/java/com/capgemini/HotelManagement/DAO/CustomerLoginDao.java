package com.capgemini.HotelManagement.DAO;

public interface CustomerLoginDao {

	public boolean login();

	public boolean customerOperations();

}
