package com.capgemini.HotelManagement.Service;

public interface CustomerLoginService {
	
	public boolean customerLoginService();
}
