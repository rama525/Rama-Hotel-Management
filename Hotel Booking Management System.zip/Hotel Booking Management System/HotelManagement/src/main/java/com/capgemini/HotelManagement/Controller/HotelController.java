package com.capgemini.HotelManagement.Controller;

import java.util.Scanner;
import org.apache.log4j.Logger;
import com.capgemini.HotelManagement.Service.AdminService;
import com.capgemini.HotelManagement.Service.CustomerLoginService;
import com.capgemini.HotelManagement.Service.HotelManagementService;
import com.capgemini.HotelManagement.Service.RegistrationService;
import com.capgemini.HotelManagement.Controller.HotelController;
import com.capgemini.HotelManagement.Factory.Factory;
import com.capgemini.HotelManagement.Validation.InputValidation;

public class HotelController {

	static final Logger log = Logger.getLogger(HotelController.class);

	static Scanner sc = new Scanner(System.in);

	public void hotelManagementSystem() {

		log.info("Select the options below");
		InputValidation inputValidations = Factory.getInputValidationInstance();

		do {

			log.info("1. Customer Login");
			log.info("2. Admin Login");
			log.info("3. HotelManagemet Login");
			log.info("4. Customer Registration(new user)");
			log.info("5. Exit");
			String choice1 = sc.next();
			while (!inputValidations.choiceValidate(choice1)) {
				log.info(" enter valid choice");
				choice1 = sc.next();
			}
			int choice = Integer.parseInt(choice1);

			switch (choice) {
			case 1:
				CustomerLoginService customerLogin = Factory.getCustomerLoginServiceImplInstance();
				customerLogin.customerLoginService();
				break;
			case 2:

				AdminService adminService = Factory.getAdminServiceImplInstance();
				adminService.adminService();
				break;

			case 3:

				HotelManagementService hotelManagementService = Factory.getHotelManagementServiceImplInstance();
				hotelManagementService.hotelManagementService();
				break;
			case 4:

				RegistrationService registerService = Factory.getRegistrationServiceImplInstance();
				registerService.registerService();
				break;
			case 5:

				System.exit(0);
				sc.close();
				break;

			}
		} while (true);

	}

	public static void main(String[] args) {

		log.info("Hotel Booking Management System");
		Factory.getHotelControllerInstance().hotelManagementSystem();

	}

}
