package com.capgemini.HotelManagement.Service;

import com.capgemini.HotelManagement.DAO.AdminLoginDao;
import com.capgemini.HotelManagement.Factory.Factory;

public class AdminServiceImpl implements AdminService {

	public boolean adminService() {
		AdminLoginDao adminDao = Factory.getLoginDaoImplInstance();
		adminDao.adminLogin();
		return false;
	}

}
