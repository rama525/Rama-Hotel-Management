package com.capgemini.HotelManagement.Exception;

public class HotelNameNotFoundException extends RuntimeException {
	
	String message = "Hotel not found";
	
	public String getMessage() {
		return message;

	}
}
