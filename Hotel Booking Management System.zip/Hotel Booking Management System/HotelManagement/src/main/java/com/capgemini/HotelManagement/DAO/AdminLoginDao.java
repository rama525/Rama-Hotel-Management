package com.capgemini.HotelManagement.DAO;

public interface AdminLoginDao {

	public void adminLogin();
}
