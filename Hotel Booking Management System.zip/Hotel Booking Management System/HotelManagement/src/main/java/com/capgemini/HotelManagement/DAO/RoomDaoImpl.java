package com.capgemini.HotelManagement.DAO;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import org.apache.log4j.Logger;
import com.capgemini.HotelManagement.Bean.Room;
import com.capgemini.HotelManagement.Exception.RoomNumberNotFoundException;
import com.capgemini.HotelManagement.Factory.Factory;

public class RoomDaoImpl implements RoomDao {

	static final Logger log = Logger.getLogger(RoomDaoImpl.class);
	static List<Room> roomList = new ArrayList<Room>();
	Scanner scanner = new Scanner(System.in);

	static {

		Room room = Factory.getRoomInstance();

		room.setRoomNumber(111);
		room.setRoomType("Single");

		roomList.add(room);
	}

	public boolean addRoom() {

		Room room = Factory.getRoomInstance();

		log.info("Please enter room type(single/double)");
		String roomType = scanner.nextLine();
		while (!Factory.getInputValidationInstance().roomTypeValidation(roomType)) {
			log.info("please enter valid type");
			roomType = scanner.nextLine();
		}

		log.info("Please enter room number(3 digits)");
		String roomNumber = scanner.next();
		while (!Factory.getInputValidationInstance().roomNumberValidation(roomNumber)) {
			log.info("please enter valid room number");
			roomNumber = scanner.next();
		}
		int roomNumber1 = Integer.parseInt(roomNumber);
		room.setRoomNumber(roomNumber1);
		room.setRoomType(roomType);

		ArrayList<Room> roomList1 = new ArrayList<Room>();
		roomList1.add(room);
		roomList.addAll(roomList1);
		if (roomList1.isEmpty()) {
			log.error("New room details are not added");
		} else {
			log.info("New  room details are added ");
		}
		return false;
	}

	public boolean deleteRoom(String roomNumber) {
		int count = 0;
		Iterator<Room> room = roomList.iterator();
		while (room.hasNext()) {
			Room str = room.next();
			int roomNumber1 = Integer.parseInt(roomNumber);
			if (str.getRoomNumber() == roomNumber1) {
				count++;
				room.remove();
				log.info("Data deleted successfully");
			}
		}
		try {
			if (count == 0) {
				throw new RoomNumberNotFoundException();
			}
		} catch (RoomNumberNotFoundException e) {
			log.info(" room number not found ");
		}
		return false;

	}

	public boolean updateRoom(Room room) {
		log.info("Enter room number(3 digits)");
		String roomNum1 = scanner.next();
		while (!Factory.getInputValidationInstance().roomNumberValidation(roomNum1)) {
			log.info("please enter valid room number ");
			roomNum1 = scanner.nextLine();
		}
		int roomNumber1 = Integer.parseInt(roomNum1);
		int count = 0;
		;
		for (Room room1 : roomList) {

			if (room1.getRoomNumber() == roomNumber1) {
				count++;

				log.info("Request is Done ");
				log.info("update details");

				log.info("update room number(3 digits)");
				String roomNumber = scanner.next();
				while (!Factory.getInputValidationInstance().roomNumberValidation(roomNumber)) {
					log.info("please enter valid room number ");
					roomNumber = scanner.nextLine();
				}

				int roomNum = Integer.parseInt(roomNumber);

				room1.setRoomNumber(roomNum);

				log.info("update room type(single/double");
				String roomType = scanner.next();
				while (!Factory.getInputValidationInstance().roomTypeValidation(roomType)) {
					log.info("please enter valid room type");
					roomType = scanner.nextLine();
				}

				room1.setRoomType(roomType);

			}

		}
		try {
			if (count == 0) {
				throw new RoomNumberNotFoundException();

			} else {
				log.info("Room Details Updated Sucessfully");

			}
		} catch (RoomNumberNotFoundException e) {
			log.info("Room Number Not Found");
		}
		return false;

	}
}
