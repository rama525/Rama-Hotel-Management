package com.capgemini.HotelManagement.DAO;

import java.util.List;

import com.capgemini.HotelManagement.Bean.Hotel;

public interface HotelDao {

	public boolean addHotel();

	public boolean deleteHotel(String hotelName);

	public boolean updateHotel(Hotel hotel1);

	public List<Hotel> getAllHotelDetails();
}
