package com.capgemini.HotelManagement.Service;

public interface HotelManagementService {
	
	public boolean hotelManagementService();
}
