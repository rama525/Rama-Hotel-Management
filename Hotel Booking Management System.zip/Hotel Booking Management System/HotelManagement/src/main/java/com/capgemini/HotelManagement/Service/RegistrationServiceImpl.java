package com.capgemini.HotelManagement.Service;

import org.apache.log4j.Logger;
import com.capgemini.HotelManagement.Bean.CustomerRegistration;
import com.capgemini.HotelManagement.DAO.CustomerRegistrationDao;
import com.capgemini.HotelManagement.Factory.Factory;

public class RegistrationServiceImpl implements RegistrationService {

	static Logger log = Logger.getLogger(RegistrationServiceImpl.class);
	CustomerRegistrationDao customer = Factory.getRegistrationDAOInstance();
	CustomerRegistration customerregister = Factory.getCustomerRegistration();

	public boolean registerService() {
		customer.register(customerregister);

		return true;
	}

	CustomerRegistrationDao customerlogin = Factory.getRegistrationDAOInstance();
}