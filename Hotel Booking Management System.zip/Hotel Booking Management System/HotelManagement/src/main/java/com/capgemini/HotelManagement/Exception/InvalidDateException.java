package com.capgemini.HotelManagement.Exception;

@SuppressWarnings("serial")
public class InvalidDateException extends Exception {
	public InvalidDateException() {

	}
}
