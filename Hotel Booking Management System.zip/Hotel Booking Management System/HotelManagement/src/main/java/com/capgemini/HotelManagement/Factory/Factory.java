package com.capgemini.HotelManagement.Factory;

import com.capgemini.HotelManagement.Validation.InputValidation;
import com.capgemini.HotelManagement.Validation.InputValidationImpl;
import com.capgemini.HotelManagement.Bean.AdminLogin;
import com.capgemini.HotelManagement.Bean.Booking;
import com.capgemini.HotelManagement.Bean.CustomerRegistration;
import com.capgemini.HotelManagement.Bean.Hotel;
import com.capgemini.HotelManagement.Bean.HotelManagementLogin;
import com.capgemini.HotelManagement.Bean.Room;
import com.capgemini.HotelManagement.Controller.HotelController;
import com.capgemini.HotelManagement.DAO.BookingDaoImpl;
import com.capgemini.HotelManagement.DAO.AdminDaoImpl;
import com.capgemini.HotelManagement.DAO.AdminLoginDaoImpl;
import com.capgemini.HotelManagement.DAO.CustomerLoginDao;
import com.capgemini.HotelManagement.DAO.CustomerLoginDaoImpl;
import com.capgemini.HotelManagement.DAO.CustomerRegistrationDao;
import com.capgemini.HotelManagement.DAO.CustomerRegistrationDaoImpl;
import com.capgemini.HotelManagement.DAO.HotelDaoImpl;
import com.capgemini.HotelManagement.DAO.HotelManagementDaoImpl;
import com.capgemini.HotelManagement.DAO.RoomDaoImpl;
import com.capgemini.HotelManagement.Service.AdminService;
import com.capgemini.HotelManagement.Service.AdminServiceImpl;
import com.capgemini.HotelManagement.Service.CustomerLoginService;
import com.capgemini.HotelManagement.Service.CustomerLoginServiceImpl;
import com.capgemini.HotelManagement.Service.HotelManagementService;
import com.capgemini.HotelManagement.Service.HotelManagementServiceImpl;
import com.capgemini.HotelManagement.Service.RegistrationService;
import com.capgemini.HotelManagement.Service.RegistrationServiceImpl;

public abstract class Factory {

	public static CustomerRegistration getCustomerRegistration() {
		CustomerRegistration customerRegisteration = new CustomerRegistration();
		return customerRegisteration;

	}

	public static CustomerRegistrationDao getRegistrationDAOInstance() {
		CustomerRegistrationDao registerDao = new CustomerRegistrationDaoImpl();
		return registerDao;
	}

	public static InputValidation getInputValidationInstance() {

		return new InputValidationImpl();
	}

	public static CustomerLoginDao getLoginDaoInstance() {
		CustomerLoginDao loginDao = new CustomerLoginDaoImpl();
		return loginDao;
	}

	public static AdminLoginDaoImpl getLoginDaoImplInstance() {

		return new AdminLoginDaoImpl();
	}

	public static AdminDaoImpl getAdminDaoImplInstance() {
		return new AdminDaoImpl();
	}

	public static Booking getBookingInstance() {
		return new Booking();
	}

	public static BookingDaoImpl getBookingDaoImplInstance() {
		return new BookingDaoImpl();
	}

	public static AdminLogin getAdminInstance() {
		return new AdminLogin();
	}

	public static Hotel getHotelInstance() {
		return new Hotel();
	}

	public static HotelDaoImpl getHotelDaoImplInstance() {
		return new HotelDaoImpl();
	}

	public static Room getRoomInstance() {
		return new Room();
	}

	public static RoomDaoImpl getRoomDaoImplInstance() {
		return new RoomDaoImpl();
	}

	public static HotelController getHotelControllerInstance() {
		return new HotelController();
	}

	public static HotelManagementLogin getHotelManagementLoginInstance() {
		return new HotelManagementLogin();
	}

	public static HotelManagementDaoImpl getHotelManagementDaoImpl() {
		return new HotelManagementDaoImpl();

	}

	public static HotelManagementService getHotelManagementServiceImplInstance() {
		return new HotelManagementServiceImpl();
	}

	public static AdminService getAdminServiceImplInstance() {
		return new AdminServiceImpl();
	}

	public static RegistrationService getRegistrationServiceImplInstance() {
		return new RegistrationServiceImpl();
	}

	public static CustomerLoginService getCustomerLoginServiceImplInstance() {
		return new CustomerLoginServiceImpl();
	}

}
