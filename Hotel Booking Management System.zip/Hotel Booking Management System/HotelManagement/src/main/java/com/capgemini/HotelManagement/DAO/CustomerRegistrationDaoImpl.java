package com.capgemini.HotelManagement.DAO;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import org.apache.log4j.Logger;
import com.capgemini.HotelManagement.Bean.CustomerRegistration;
import com.capgemini.HotelManagement.Factory.Factory;
import com.capgemini.HotelManagement.Validation.InputValidation;

public class CustomerRegistrationDaoImpl implements CustomerRegistrationDao {
	static final Logger log = Logger.getLogger(CustomerRegistrationDaoImpl.class);
	int count = 0;
	InputValidation inputValidations = null;
	static List<CustomerRegistration> customer = new ArrayList<CustomerRegistration>();
	static int size;
	Scanner sc1 = new Scanner(System.in);

	static {

		CustomerRegistration customer1 = Factory.getCustomerRegistration();
		customer1.setName("ranganath kuntumalla");
		customer1.setUsername("ranganath12");
		customer1.setPassword("Ranganath#12");
		customer1.setPhno(9666927492l);
		customer1.setMailId("ranganath@gmail.com");
		customer1.setAge(23);

		CustomerRegistration customer2 = Factory.getCustomerRegistration();
		customer2.setName("ramanath kota");
		customer2.setUsername("ramanath23");
		customer2.setPassword("Ramanath#23");
		customer2.setPhno(9000807962l);
		customer2.setMailId("ramanath@gmail.com");
		customer2.setAge(22);

		CustomerRegistration customer3 = Factory.getCustomerRegistration();
		customer3.setName("sukanya reddy");
		customer3.setUsername("sukanya55");
		customer3.setPassword("Sukanya$55");
		customer3.setPhno(9856425457l);
		customer3.setMailId("sukanya@gmail.com");
		customer3.setAge(24);

		customer.add(customer1);
		customer.add(customer2);
		customer.add(customer3);
		size = customer.size();

	}

	public boolean register(CustomerRegistration customerRegistration) {
		InputValidation inputValidation = Factory.getInputValidationInstance();
		CustomerRegistration cr = Factory.getCustomerRegistration();
		log.info("Enter your name(firstname lastname)");
		String name = sc1.nextLine();
		while (!inputValidation.nameValidation(name)) {
			log.info("please enter valid name(firstname lastname)");
			name = sc1.nextLine();
		}

		log.info("Enter username(start with digits or characters,-,_)");
		String username = sc1.nextLine();
		while (!inputValidation.usernameValidation(username)) {
			log.info("please enter valid username(start with digits or characters,-,_)");
			username = sc1.nextLine();
		}

		log.info(
				"Enter password(must contain uppercase letter,lowercase letter,special characters @#$%,atleast one digit,minimum 6 max 20)");
		String password = sc1.next();
		while (!inputValidation.passwordValidation(password)) {
			log.info(
					"please enter valid password(must contain uppercase letter,lowercase letter,special characters @#$%,atleast one digit,minimum 6 max 20)");
			password = sc1.next();
		}

		log.info("Enter phno(start with 7,8,9)");
		String phone = sc1.next();
		while (!inputValidation.phnoValidation(phone)) {
			log.info("please enter valid phno(start with 7,8,9)");
			phone = sc1.next();
		}
		long phno = Long.parseLong(phone);

		log.info("Enter mailId(must contain @ .)");
		String mailid = sc1.next();
		while (!inputValidation.emailValidation(mailid)) {
			log.info("please enter valid mailid(must contain @ .)");
			mailid = sc1.next();
		}
		log.info("Enter your age(2 digits)");
		String age1 = sc1.next();
		while (!inputValidation.ageValidation(age1)) {
			log.info("please enter valid age");
			age1 = sc1.next();
		}

		int age = Integer.parseInt(age1);
		cr.setName(name);
		cr.setUsername(username);
		cr.setPhno(phno);
		cr.setAge(age);
		cr.setMailId(mailid);
		cr.setPassword(password);

		ArrayList<CustomerRegistration> list = new ArrayList<CustomerRegistration>();

		list.add(cr);
		customer.addAll(list);
		if (list.isEmpty()) {
			log.info("Registration unsuccessful\n");
			return false;
		} else {
			log.info("Registration successfull");

			return true;

		}
	}

	public List<CustomerRegistration> getAllCustomers() {
		log.info("list of Customers");

		for (int i = 0; i < customer.size(); i++) {
			log.info("\n" + customer.get(i));
		}
		return customer;
	}
}