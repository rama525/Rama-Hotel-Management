package com.capgemini.HotelManagement.Exception;

@SuppressWarnings("serial")
public class RoomNumberNotFoundException extends Exception {

	public RoomNumberNotFoundException() {

	}
}
