package com.capgemini.HotelManagement.Bean;

public class CustomerRegistration {

	private String name;
	private String username;
	private String password;
	private long phno;
	private String mailId;
	private int age;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public long getPhno() {
		return phno;
	}

	public void setPhno(long phno) {
		this.phno = phno;
	}

	public String getMailId() {
		return mailId;
	}

	public void setMailId(String mailId) {
		this.mailId = mailId;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	@Override
	public String toString() {
		return "CustomerRegistration [name=" + name + ", username=" + username + ", password=" + password + ", phno="
				+ phno + ", mailId=" + mailId + ", age=" + age + "]";
	}
}
