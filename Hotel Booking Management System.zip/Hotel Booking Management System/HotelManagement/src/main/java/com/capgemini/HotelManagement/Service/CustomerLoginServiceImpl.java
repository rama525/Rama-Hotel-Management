package com.capgemini.HotelManagement.Service;

import com.capgemini.HotelManagement.Controller.HotelController;

import com.capgemini.HotelManagement.DAO.CustomerLoginDao;
import com.capgemini.HotelManagement.Factory.Factory;
import org.apache.log4j.*;

public class CustomerLoginServiceImpl implements CustomerLoginService {
	static final Logger log = Logger.getLogger(HotelController.class);
	CustomerLoginDao customerlogindao = Factory.getLoginDaoInstance();

	public boolean customerLoginService() {
		customerlogindao.login();
		return true;

	}
}
