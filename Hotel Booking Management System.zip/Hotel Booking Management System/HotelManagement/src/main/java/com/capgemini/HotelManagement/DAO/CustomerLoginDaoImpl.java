package com.capgemini.HotelManagement.DAO;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import org.apache.log4j.Logger;
import com.capgemini.HotelManagement.Bean.CustomerRegistration;
import com.capgemini.HotelManagement.Factory.Factory;
import com.capgemini.HotelManagement.Validation.InputValidation;

public class CustomerLoginDaoImpl implements CustomerLoginDao {
	Logger log = Logger.getLogger(CustomerLoginDaoImpl.class);
	Scanner sc = new Scanner(System.in);
	CustomerRegistration cr = Factory.getCustomerRegistration();
	CustomerRegistrationDao customer = Factory.getRegistrationDAOInstance();
	List<CustomerRegistration> custlist = new ArrayList<CustomerRegistration>(CustomerRegistrationDaoImpl.customer);

	public boolean login() {
		InputValidation inputValidation = Factory.getInputValidationInstance();
		log.info("Enter username");
		String username = sc.nextLine();
		while (!inputValidation.usernameValidation(username)) {
			log.info("please enter valid username");
			username = sc.next();
		}

		log.info("Enter password");
		String password = sc.next();
		while (!inputValidation.passwordValidation(password)) {
			log.info("please enter valid password");
			password = sc.next();
		}
		int count = 0;
		Iterator<CustomerRegistration> itr = custlist.iterator();

		while (itr.hasNext()) {

			CustomerRegistration customer1 = itr.next();

			if (username.equals(customer1.getUsername()) && password.equals(customer1.getPassword())) {
				count++;

			}
		}

		if (count == 0) {
			log.info("Login Fail");
		} else {
			log.info("Login success");
			customerOperations();
		}
		return false;

	}

	public boolean customerOperations() {
		do {
			log.info("1.Hotel booking");
			log.info("2.exit");
			String choice = sc.next();
			while (!Factory.getInputValidationInstance().choiceValidateCustomerOperations(choice)) {
				log.error("Please enter valid choice");
				choice = sc.next();
			}

			int choice1 = Integer.parseInt(choice);

			switch (choice1) {
			case 1:
				Factory.getBookingDaoImplInstance().BookingHotel();
				break;

			case 2:
				Factory.getHotelControllerInstance().hotelManagementSystem();
				break;
			}
		} while (true);
	}

}
