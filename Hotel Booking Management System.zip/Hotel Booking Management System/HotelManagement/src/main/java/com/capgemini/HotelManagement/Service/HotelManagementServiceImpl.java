package com.capgemini.HotelManagement.Service;

import com.capgemini.HotelManagement.DAO.HotelManagementDao;
import com.capgemini.HotelManagement.Factory.Factory;

public class HotelManagementServiceImpl implements HotelManagementService {

	public boolean hotelManagementService() {
		HotelManagementDao hotelManagement = Factory.getHotelManagementDaoImpl();
		hotelManagement.getEmployeeLogin();
		return false;
	}

}
