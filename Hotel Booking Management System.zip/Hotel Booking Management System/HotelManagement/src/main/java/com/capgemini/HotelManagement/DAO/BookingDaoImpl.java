package com.capgemini.HotelManagement.DAO;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import org.apache.log4j.Logger;
import com.capgemini.HotelManagement.Bean.Booking;
import com.capgemini.HotelManagement.Factory.Factory;
import com.capgemini.HotelManagement.DAO.BookingDao;
import com.capgemini.HotelManagement.Exception.InvalidDateException;

public class BookingDaoImpl implements BookingDao {

	static final Logger log = Logger.getLogger(BookingDaoImpl.class);

	int count = 0;
	static List<Booking> bookList = new ArrayList<Booking>();

	Scanner sc = new Scanner(System.in);

	static {

		Booking booking = Factory.getBookingInstance();

		booking.setFromDate(LocalDate.of(2020, 01, 15));
		booking.setToDate(LocalDate.of(2020, 01, 16));
		booking.setName("rama");
		booking.setHotelName("Taj Hotel");
		booking.setAddress("hyderabad");
		booking.setEmail("rama525@gmail.com");
		booking.setContactNumber(9000807962l);
		booking.setRoomNum(111);

		Booking booking2 = Factory.getBookingInstance();

		booking2.setFromDate(LocalDate.of(2020, 04, 25));
		booking2.setToDate(LocalDate.of(2020, 04, 26));
		booking2.setName("geetha");
		booking2.setHotelName("AthithiGrand Hotel");
		booking2.setAddress("nandhyal");
		booking2.setEmail("geetha123@gmail.com");
		booking2.setContactNumber(7674081102l);
		booking2.setRoomNum(112);

		Booking booking3 = Factory.getBookingInstance();

		booking3.setFromDate(LocalDate.of(2020, 05, 01));
		booking3.setToDate(LocalDate.of(2020, 05, 02));
		booking3.setName("lucky");
		booking3.setHotelName("Taj Hotel");
		booking3.setAddress("Banglore");
		booking3.setEmail("lucky@gmail.com");
		booking3.setContactNumber(9666927492l);
		booking3.setRoomNum(113);

		bookList.add(booking);
		bookList.add(booking2);
		bookList.add(booking3);
	}

	public List<Booking> getBookingDetails() {

		for (int i = 0; i < bookList.size(); i++) {
			log.info("\n" + bookList.get(i));
		}
		return bookList;
	}

	public Booking getBookingDetailsForSpecificDate(LocalDate bookingDate) {
		int count = 0;
		for (Booking booking : bookList) {
			if (booking.getFromDate().equals(bookingDate)) {
				count++;
				List<Booking> searchBooking = new ArrayList<Booking>();
				searchBooking.add(booking);
				log.info(searchBooking);
			}
		}
		try {
			if (count == 0)
				throw new InvalidDateException();
		} catch (InvalidDateException e) {
			log.info("No Bookings in such Date");
		}

		return null;
	}

	public boolean addBooking(Booking booking) {

		log.info("Please enter from date(FORMAT:YYYY/MM/DD)");
		String fromdate = sc.next();
		while (!Factory.getInputValidationInstance().bookingDateValidation(fromdate)) {
			log.info("Please enter valid date(FORMAT:YYYY/MM/DD)");
			fromdate = sc.next();
		}

		LocalDate fromDate = LocalDate.parse(fromdate);
		while (fromDate.isBefore(LocalDate.now())) {
			log.info("please enter a valid Date");
			fromdate = sc.next();
			while (!Factory.getInputValidationInstance().bookingDateValidation(fromdate)) {
				log.info("Please enter valid date in the format  YYYY/MM/DD");
				fromdate = sc.next();
			}
			fromDate = LocalDate.parse(fromdate);

		}
		log.info("Please enter To date(FORMAT:YYYY/MM/DD)");
		String todate = sc.next();
		while (!Factory.getInputValidationInstance().bookingDateValidation(todate)) {
			log.error("Please enter valid date(FORMAT:YYYY/MM/DD)");
			todate = sc.next();
		}

		LocalDate toDate = LocalDate.parse(todate);
		if (toDate.isBefore(fromDate)) {
			log.info("please enter a valid Date");
			todate = sc.next();
			while (!Factory.getInputValidationInstance().bookingDateValidation(todate)) {
				log.info("Please enter valid date in the format  YYYY/MM/DD");
				todate = sc.next();
			}
			toDate = LocalDate.parse(todate);

		}

		log.info("Please enter your name");
		String name = sc.next();
		while (!Factory.getInputValidationInstance().bookingNameValidation(name)) {
			log.info("please enter valid name");
			name = sc.next();
		}

		log.info("Please enter your address");
		String address = sc.next();
		while (!Factory.getInputValidationInstance().hotelAddressValidation(address)) {
			log.error("Please enter valid  address");
			address = sc.nextLine();
		}

		log.info("Please enter email(include @ .)");
		String email = sc.next();
		while (!Factory.getInputValidationInstance().emailValidation(email)) {
			log.error("Please enter valid  email(include @ .)");
			email = sc.next();
		}

		log.info("Please enter contact number(start with 7,8,9)");
		String contactNumber = sc.next();
		while (!Factory.getInputValidationInstance().hotelContactNumberValidation(contactNumber)) {
			log.error("Please enter valid contact number(start with 7,8,9)");
			contactNumber = sc.next();
		}

		Long contactNumber1 = Long.parseLong(contactNumber);

		log.info("Please enter room number(must have 3 digits)");
		String roomNum = sc.next();
		while (!Factory.getInputValidationInstance().roomNumberValidation(roomNum)) {
			log.info("please enter valid room number(must have 3 digits)");
			roomNum = sc.next();
		}
		int roomNum1 = Integer.parseInt(roomNum);

		booking.setFromDate(fromDate);
		booking.setToDate(toDate);
		booking.setName(name);
		booking.setAddress(address);
		booking.setEmail(email);
		booking.setContactNumber(contactNumber1);
		booking.setRoomNum(roomNum1);

		ArrayList<Booking> list = new ArrayList<Booking>();
		list.add(booking);
		bookList.addAll(list);
		if (list.isEmpty()) {
			log.error("Booking failed");
			log.info("please try again");
			return false;
		} else {
			log.info("Booking Successful");
			log.info("Booking Details:\n " + booking.toString());
			return true;
		}

	}

	public boolean BookingHotel() {

		log.info("Booking For Hotel");

		do {
			log.info("Please select, which hotel you want to book");
			Factory.getAdminDaoImplInstance().listOfHotels();
			log.info("Please enter hotel name");
			String hotelName = sc.nextLine();
			while (!Factory.getInputValidationInstance().hotelNameValidation(hotelName)) {
				log.error("Please enter valid hotel name ");
				hotelName = sc.nextLine();
			}
			addBooking(Factory.getBookingInstance());

			return true;
		} while (true);
	}

	public List<Booking> getBookingDetailsForSpecificHotel(String hotelName) {
		for (Booking booking : bookList) {
			if (booking.getHotelName().equals(hotelName)) {
				List<Booking> searchBooking = new ArrayList<Booking>();
				searchBooking.add(booking);
				log.info("\n\n" + searchBooking + "\n");
			}
		}
		return bookList;
	}

}
