package com.capgemini.HotelManagement.DAO;

import java.util.List;

import com.capgemini.HotelManagement.Bean.CustomerRegistration;

public interface CustomerRegistrationDao {

	public boolean register(CustomerRegistration customerRegistration);

	public List<CustomerRegistration> getAllCustomers();

}
