package com.capgemini.HotelManagement;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;

import org.apache.log4j.Logger;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import com.capgemini.HotelManagement.Bean.Booking;
import com.capgemini.HotelManagement.DAO.BookingDao;
import com.capgemini.HotelManagement.Factory.Factory;

class BookingTest {

	static final Logger log = Logger.getLogger(BookingTest.class);
	Booking booking = Factory.getBookingInstance();

	@Test
	@DisplayName("Add Booking")
	void testAddBooking() {
		log.info("Test Case for Add Booking");
		BookingDao bookingDAO = Factory.getBookingDaoImplInstance();
		assertEquals(true, bookingDAO.addBooking(booking));
	}

	@Test
	@DisplayName("Get Booking Details")
	void testGetBookingDetails() {
		log.info("Test Case for Get Booking Details");
		BookingDao bookingDAO = Factory.getBookingDaoImplInstance();
		assertNotNull(bookingDAO.getBookingDetails());
	}

	@Test
	@DisplayName("Booking Details for Specific Date")
	void testBookingDetailsForSpecificDate() {
		log.info("Test Case for Booking Details of Specific Date");
		BookingDao bookingDAO = Factory.getBookingDaoImplInstance();
		assertNotNull(bookingDAO.getBookingDetailsForSpecificDate(LocalDate.of(2020, 04, 25)));
	}

	@Test
	@DisplayName("Booking Details for Specific Hotel")
	void testBookingDetailsForSpecificHotel() {
		log.info("Test Case for Booking Details of Specific Hotel");
		BookingDao bookingDAO = Factory.getBookingDaoImplInstance();
		assertNotNull(bookingDAO.getBookingDetailsForSpecificHotel("Taj Hotel"));
	}
}
