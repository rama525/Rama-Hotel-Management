package com.capgemini.HotelManagement.DAO;

import com.capgemini.HotelManagement.Bean.Room;

public interface RoomDao {

	public boolean addRoom();

	public boolean deleteRoom(String roomNumber);

	public boolean updateRoom(Room room1);
}
