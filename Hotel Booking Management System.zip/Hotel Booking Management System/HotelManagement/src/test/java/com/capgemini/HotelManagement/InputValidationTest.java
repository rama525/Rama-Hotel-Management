package com.capgemini.HotelManagement;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import com.capgemini.HotelManagement.Factory.Factory;
import com.capgemini.HotelManagement.Validation.InputValidation;

public class InputValidationTest {
	@Test
	@DisplayName("CustomerName")
	void testCustomerName() {
		InputValidation customerNameValidation = Factory.getInputValidationInstance();
		assertEquals(true, customerNameValidation.nameValidation("ranganath kuntumalla"));
	}

	@Test
	@DisplayName("email")
	void testMailId() {
		InputValidation emailValidation = Factory.getInputValidationInstance();
		assertEquals(true, emailValidation.emailValidation("ranganath@gmail.com"));
	}

	@Test
	@DisplayName("contact number")
	void testPhno() {
		InputValidation phnoValidation = Factory.getInputValidationInstance();
		assertEquals(false, phnoValidation.phnoValidation("9666927492l"));
	}

	@Test
	@DisplayName("username")
	void testUserName() {
		InputValidation usernameValidation = Factory.getInputValidationInstance();
		assertEquals(true, usernameValidation.usernameValidation("ranganath12"));
	}

	@Test
	@DisplayName("password")
	void testPassword() {
		InputValidation passwordValidation = Factory.getInputValidationInstance();
		assertEquals(true, passwordValidation.passwordValidation("Ranganath#12"));
	}

	@Test
	@DisplayName("age")
	void testAge() {
		InputValidation ageValidation = Factory.getInputValidationInstance();
		assertEquals(true, ageValidation.ageValidation("23"));
	}

	@Test
	@DisplayName("coice")
	void testChoice() {
		InputValidation choiceValidation = Factory.getInputValidationInstance();
		assertEquals(true, choiceValidation.choiceValidate("2"));
	}

	@Test
	@DisplayName("coiceAdmin")
	void testAdminChoice() {
		InputValidation adminchoiceValidation = Factory.getInputValidationInstance();
		assertEquals(true, adminchoiceValidation.choiceValidateAdminOperation("3"));
	}

	@Test
	@DisplayName("specificHotelcoice")
	void testSpecificHotelChoice() {
		InputValidation specifichotelchoiceValidation = Factory.getInputValidationInstance();
		assertEquals(true, specifichotelchoiceValidation.choiceValidateBookingForSpecificHotel("2"));
	}

	@Test
	@DisplayName("booking date")
	void testBookingDate() {
		InputValidation bookingDateValidation = Factory.getInputValidationInstance();
		assertEquals(true, bookingDateValidation.bookingDateValidation("2020-05-01"));
	}

	@Test
	@DisplayName("hotel name")
	void testHotelName() {
		InputValidation hotelNameValidation = Factory.getInputValidationInstance();
		assertEquals(true, hotelNameValidation.hotelNameValidation("Taj Hotel"));
	}

	@Test
	@DisplayName("hotel adress")
	void testHotelAdress() {
		InputValidation hotelAdressValidation = Factory.getInputValidationInstance();
		assertEquals(true, hotelAdressValidation.hotelAddressValidation("bangalore"));
	}

	@Test
	@DisplayName("hotel contact number")
	void testHotelContactNumber() {
		InputValidation hotelContactNumberValidation = Factory.getInputValidationInstance();
		assertEquals(true, hotelContactNumberValidation.hotelContactNumberValidation("9547860213"));
	}

	@Test
	@DisplayName("hotel details choice")
	void testHotelDetailsChoice() {
		InputValidation hotelDeatilsChoiceValidation = Factory.getInputValidationInstance();
		assertEquals(true, hotelDeatilsChoiceValidation.choiceValidateOperateHotelDetails("2"));
	}

	@Test
	@DisplayName("Room details choice")
	void testRoomDetailsChoice() {
		InputValidation roomDeatilsChoiceValidation = Factory.getInputValidationInstance();
		assertEquals(true, roomDeatilsChoiceValidation.choiceValidateOperateRoomDetails("2"));
	}

	@Test
	@DisplayName("Customer Operations")
	void testCustomerOperations() {
		InputValidation customerOperationsValidation = Factory.getInputValidationInstance();
		assertEquals(true, customerOperationsValidation.choiceValidateCustomerOperations("2"));
	}

	@Test
	@DisplayName("Employee Operations")
	void testEmployeeOperations() {
		InputValidation employeeOperationsValidation = Factory.getInputValidationInstance();
		assertEquals(true, employeeOperationsValidation.choiceValidateEmployeeOperations("2"));
	}

	@Test
	@DisplayName("room number")
	void testRoomNumber() {
		InputValidation roomNumberValidation = Factory.getInputValidationInstance();
		assertEquals(true, roomNumberValidation.roomNumberValidation("111"));
	}

	@Test
	@DisplayName("room type")
	void testRoomType() {
		InputValidation roomTypeValidation = Factory.getInputValidationInstance();
		assertEquals(true, roomTypeValidation.roomNumberValidation("single"));
	}

	@Test
	@DisplayName("number of rooms")
	void testNumberOfRooms() {
		InputValidation noOfRoomsValidation = Factory.getInputValidationInstance();
		assertEquals(true, noOfRoomsValidation.numberOfRoomsValidation("26"));
	}

	@Test
	@DisplayName("booking name")
	void testBookingName() {
		InputValidation bookingNameValidation = Factory.getInputValidationInstance();
		assertEquals(true, bookingNameValidation.bookingNameValidation("rama"));
	}

	@Test
	@DisplayName("update customer details")
	void testUpdateCustomerDetails() {
		InputValidation customerdetailsValidation = Factory.getInputValidationInstance();
		assertEquals(true, customerdetailsValidation.choiceUpdateCustomerDetailsValidate("3"));

	}

}
