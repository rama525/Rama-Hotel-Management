package com.capgemini.HotelManagement.DAO;

public interface AdminDao {

	public void listOfHotels();

	public void bookingForSpecificHotel();

	public void bookingForSpecificDate();

	public void operateHotelDetails();

	public void operateRoomDetails();

}
