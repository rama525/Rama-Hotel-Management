package com.capgemini.HotelManagement.DAO;

public interface HotelManagementDao {

	public boolean getEmployeeLogin();

	public boolean employeeOperations();

}
